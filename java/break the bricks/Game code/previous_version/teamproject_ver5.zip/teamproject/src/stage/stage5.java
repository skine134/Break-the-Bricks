package stage;

public class stage5 extends Stage{

	@Override
	public String getH_wall() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getW_wall() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getball_image() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getBackground_image() {
		// TODO Auto-generated method stub
		return null;
	}

}
