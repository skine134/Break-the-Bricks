package stage;

import java.awt.Color;
import java.io.IOException;
import java.util.*;
import arkanoid_object.*;

public class stage3 extends Stage{

	public stage3(character ch,ball b) throws IOException {
		stage_num = 3;
		bricks = new ArrayList<brick>();
		bricks_th = new ArrayList<Thread>();
		Unbreak_bricks=new ArrayList<brick>();
		
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 2; j++) {
				bricks.add(2 * i + j, new brick());
				bricks.get(2 * i + j).setX(100 + 400 * j);
				bricks.get(2 * i + j).setY(20 * i + 300);
				bricks.get(2 * i + j).setCollision(b);
				bricks_th.add(2 * i + j, new Thread(bricks.get(2 * i + j).th));
				bricks.get(2 * i + j).getPan().setSize(bricks.get(2 * i + j).getSize_x(),
						bricks.get(2 * i + j).getSize_y());
				bricks.get(2 * i + j).getPan().setLocation(bricks.get(2 * i + j).getX(), bricks.get(2 * i + j).getY());
				if ((2 * i + j) % 4 %3== 0)
					bricks.get(2*i+j).setBrick_image("images\\Block\\Block_navy.png");
				else
					bricks.get(2*i+j).setBrick_image("images\\Block\\Block_blue.png");
			}
		}
	}

	@Override
	public String getH_wall(){
		return "images\\ice\\ice_pillar_cols.png";
	}
	@Override
	public String getW_wall(){
		return "images\\ice\\ice_pillar_rows.png";
	}
	@Override
	public String getball_image() {
		return "images\\ice\\ice_ball.png";
	}
	@Override
	public String getBackground_image() {
		return "images\\ice\\ice_back.png";
	}
}
