package teamproject_Game;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.*;
import javax.swing.*;
import arkanoid_object.*;
import event.Item;
import stage.*;

public class Game extends JFrame {

	// 배경화면
	BackgroundImage background;

	// 벽
	Wall[] wall;

	// 컨테이너
	private static Container con;

	// 공
	ball b;

	// 캐릭터(유저)
	character ch;

	// 이동을 위한 논리식
	boolean left;
	boolean right;

	// 각 스테이지 벽돌의 스레드 모음집
	HashMap<Integer, ArrayList<Thread>> bricks_th;

	// 각 스테이지 벽돌의 모음집
	HashMap<Integer, Stage> stages;
	// 아이템 관리 모음집
	public static ArrayList<Item> items = new ArrayList<Item>();;

	// 각 객채에 대한 스레드
	Thread ball_th;
	Thread ch_ball_th;
	Thread move_th;
	Thread ch_items_th;
	Runnable move;

	Game() throws IOException {
//*************************************기본 셋팅
		// 이름 지정
		setTitle("벽돌 깨기");

		// 게임 종료시 콘솔도 종료
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		// 메인 창 활성화
		setVisible(true);

		// 어플 크기 지정
		setSize(600, 1000);

		// 창 사이즈 조정 불가
		setResizable(false);

		// 컨테이너에 컨텐츠팬 삽입
		con = getContentPane();
//*************************************각 객체의 선언
		ch = new character();
		wall = new Wall[4];
		b = new ball(ch);
		background = new BackgroundImage();
		ch.setCollision(b);
		ch_ball_th = new Thread(ch.ball_th);
		ch.setCollision(items);
		ch_items_th = new Thread(ch.items_th);
		ball_th = new Thread(b.th);

		// 움직임 제어를 위한 로직
		left = false;
		right = false;

		// 각 스테이지의 벽돌들의 스레드에 대한 객체 선언
		bricks_th = new HashMap<Integer, ArrayList<Thread>>();
		
		// 각 스테이지의 벽돌들에 대한 객체 선언
		stages= new HashMap<Integer, Stage>();

		// 각 스테이지에 대한 객체 선언
		stages.put(1,new stage1(ch,b));
		stages.put(2,new stage2(ch,b));
		stages.put(3,new stage3(ch,b));
		stages.put(4,new stage4(ch,b));
		// 각 스테이지의 블록에 관한 스레드를 관리하는 컬랙션에 1스테이지의 블록들에 관한 스레드를 삽입
		bricks_th.putAll(stages.get(1).returnbricks_th());
		bricks_th.putAll(stages.get(2).returnbricks_th());
		bricks_th.putAll(stages.get(3).returnbricks_th());
		bricks_th.putAll(stages.get(4).returnbricks_th());
		
		
		// 움직임에 대한 스레드 람다식으로 지정
		move = () -> {
			while (true) {

				// 만약 right==true이면 아래의 명령어 수행
				if (right) {

					// 만약 캐릭터가 화면의 오른쪽 끝에 닿지 않았다면 현제 캐릭터의 속도만큼 캐릭터를 오른쪽으로 이동
					if (ch.getX() + ch.getSize_x() <= 582) {
						ch.setX(ch.getX() + ch.getDx());
						ch.getPan().setLocation(ch.getX(), ch.getY());
					}

					// 만약 right==true이면 아래의 명령어 수행
				} else if (left) {

					// 만약 캐릭터가 화면의 왼쪽 끝에 닿지 않았다면 현제 캐릭터의 속도만큼 캐릭터를 왼쪽으로 이동
					if (ch.getX() >= 10) {
						ch.setX(ch.getX() + ch.getDx());
						ch.getPan().setLocation(ch.getX(), ch.getY());
					}
				}
				try {
					// 위의 검사를 1초에 60번 수행(＊부러운 움직임을 위함)
					Thread.sleep(1000 / 60);
				} catch (InterruptedException e) {
					e.getMessage();
				}
			}
		};
		// move_th의 선언(move는 Runable 클래스로 선언 되었으므로 Thread에 포함 시켜주어야함).
		move_th = new Thread(move);

//*************************************배치 및 이벤트 설정

		// 컨테이너의 배치타입(Layout)을 null로 지정(크기와 좌표로 각 객체를 배치함)
		con.setLayout(null);

		// 벽에 대한 배치
		for (int i = 0; i < 4; i++) {

			// 각 벽에대한 객체 선언
			wall[i] = new Wall();

			// 만약 i가 0,1이면 10,953 로 막대 크기를 지정(세로 막대)
			if (i < 2)
				wall[i].getPan().setSize(10, 963);

			// 만약 i가 2,3이면 582,10 로 막대 크기를 지정(가로 막대)
			else
				wall[i].getPan().setSize(592, 10);
		}

		// 각 벽의 컨테이너에 배치 및 위치 지정
		con.add(wall[0].getPan());
		wall[0].getPan().setLocation(0, 0);
		con.add(wall[1].getPan());
		wall[1].getPan().setLocation(582, 0);
		con.add(wall[2].getPan());
		wall[2].getPan().setLocation(0, 0);
		con.add(wall[3].getPan());
		wall[3].getPan().setLocation(0, 953);

		// 현제 hp를 보여주는 이미지를 오른쪽 상단에 표시
		for (int i = 0; i < ch.getHp_pans().size(); i++) {
			con.add(ch.getHp_pans().get(i));
			ch.getHp_pans().get(i).setSize(50, 50);
			ch.getHp_pans().get(i).setLocation(500 - i * 50, 15);
		}

		// 캐릭터의 컨테이너에 배치 및 위치 지정
		con.add(ch.getPan());
		ch.getPan().setLocation(ch.getX(), ch.getY());

		// 공의 컨테이너에 배치 및 위치 지정
		con.add(b.getPan());
		b.getPan().setLocation(b.getX(), b.getY());

		con.add(background.getPan());
		// 컨테이너에 키보드 리스너 이벤트를 부여함
		con.addKeyListener(new KeyListener() {

			@Override // 키가 눌렸을때 이벤트(※설정안함)
			public void keyTyped(KeyEvent e) {
			}

			@Override // 키를 누르고 있을때 이벤트
			public void keyPressed(KeyEvent e) {

				// 만약에 키가 눌려있는데 그 키가 왼쪽 방향키라면 아래 명령어 수행
				if (e.getKeyCode() == KeyEvent.VK_LEFT) {
					if (right)
						right = false;

					// 만약 캐릭터의 움직이지 않고 정지 상태라면(초기 상태에서 움직이지 않음) x축 벡터를 -5로 설정
					if (ch.getDx() == 0)
						ch.setDx(-character.move_speed);
					else if (ch.getDx() > 0)

						// 만약 캐릭터가 이전에 오른쪽으로 움직이고 있었다면 x축 벡터방향을 반대로 변경
						ch.setDx(-ch.getDx());
					left = true;

					// 만약에 키가 눌려있는데 그 키가 오른 방향키라면 아래 명령어 수행
				} else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
					if (left)
						left = false;
					// 만약 캐릭터의 움직이지 않고 정지 상태라면(초기 상태에서 움직이지 않음) x축 벡터를 +5로 설정
					if (ch.getDx() == 0)
						ch.setDx(character.move_speed);

					// 만약 캐릭터가 이전에 왼쪽으로 움직이고 있었다면 x축 벡터방향을 반대로 변경
					else if (ch.getDx() < 0)
						ch.setDx(-ch.getDx());
					right = true;

				}

				// 만약에 키가 눌려있는데 그 키가 스페이스 방향키이고 공의 y축 백터가 0이라면(정지상태라면) 아래 명령어 수행
				if (e.getKeyCode() == KeyEvent.VK_SPACE && b.getDy() == 0) {

					// 캐릭터가 움직인 방향으로 공을 발사(정지해 있다면 수직으로 발사)
					if (ch.getDx() != 0) {
						if(ch.getDx()<0)
						b.setDx(-b.getSpeed() * ball.start_D);
						else
							b.setDx(b.getSpeed() * ball.start_D);
						b.setDy(-ball.start_D * b.getSpeed());
					} else
						b.setDy(-ball.start_D * b.getSpeed() * Math.sqrt(2));
				}

				// esc 버튼 클릭시 게임 종료
				if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
					System.exit(1);
				}
			}

			@Override // 누른 키가 떨어졌을때 이벤트
			public void keyReleased(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
					right = false;
					if (left == true)
						return;
				}
				if (e.getKeyCode() == KeyEvent.VK_LEFT) {
					left = false;
					if (right == true)
						return;
				}
				ch.setDx(0);
			}

		});

		// 각 스레드 동작
		ball_th.start();
		ch_ball_th.start();
		ch_items_th.start();
		move_th.start();

		// 키이벤트를 받을 수 있도록 컨테이너 설정
		con.setFocusable(true);
		con.requestFocus();

		// 스테이지별 게임 작동
		for (int i = 2; i <= bricks_th.size(); i++) {

			// 컨테이너에 n스테이지에 포함된 벽돌을 추가 및 배치
			for (int j = 0; j < stages.get(i).getBricks().size(); j++) {
				con.add(stages.get(i).getBricks().get(j).getPan());
			}

			// 각 벽에 대한 이미지 지정
			for (int j = 0; j < wall.length; j++) {
				if (j < 2)
					wall[j].setWall_image(stages.get(i).getH_wall());
				else
					wall[j].setWall_image(stages.get(i).getW_wall());

			}

			// 공의 이미지 지정
			b.setball_image(stages.get(i).getball_image());

			// 배경화면 이미지 지정
			background.setBackGround_image(stages.get(i).getBackground_image());
			
			// 배경화면을 맨 뒤로 보냄( 다른 객체들이 보이게 하기 위함)
			con.setComponentZOrder(background.getPan(), con.getComponentCount() - 1);

			// 한 스테이지가 지날 때마다 컨테이너를 동기화(이미지 최신화)시킴
			con.repaint();

			// 스테이지별 벽돌들의 스레드 작동
			for (int j = 0; j < bricks_th.get(i).size(); j++) {
				(bricks_th.get(i)).get(j).start();
			}

			// 스레드가 모두 종료 될때 까지 무한 반복(한 스테이지에 머무르게 하기 위함)
			while ((bricks_th.get(i)).size()>(stages.get(i)).getUnbreak_bricks().size()) {
				for (int j = 0; j < bricks_th.get(i).size(); j++) {
					if (!(bricks_th.get(i)).get(j).isAlive())
						bricks_th.get(i).remove(j);
				}
			}
			bricks_th.remove(i);
			stages.remove(i);
			// 공의 위치와 벡터값을 초기값으로 변경
			b.reset(ch);
		}
	}

	public static void main(String args[]) throws IOException {
		new Game();

	}

	public static Container getCon() {
		return con;
	}
}
