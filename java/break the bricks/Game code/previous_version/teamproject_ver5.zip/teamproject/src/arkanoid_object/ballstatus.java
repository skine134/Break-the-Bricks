package arkanoid_object;

import java.util.concurrent.Semaphore;

import javax.swing.ImageIcon;
import javax.swing.JComponent;

public class ballstatus extends JComponent {
	public static final double start_D=Math.sqrt(250)/2;
	public static final double min_D=5d;
	public static final double max_D=Math.sqrt(125-Math.pow(min_D,2));

	// 배속
	private double speed;

	// 이전 x,y값
	private double pre_x;
	private double pre_y;

	// 현제 x,y값
	private double x;
	private double y;

	// 공의 투명성 여부
	private boolean ballclear;

	// 공의 지름
	private int r;

	// 각 축에대한 공의 변화량
	private double dx;
	private double dy;

	// 충돌이 여러블록에서 한번에 일어 났을 경우 방향 전환이 한번만 되게 하기 외한 Semaphore
//	private Semaphore Xsema;
	private Semaphore sema;
	public double getSpeed() {
		return speed;
	}

	public double getDx() {
		return dx;
	}

	public void setDx(double dx) {
		if(sema.availablePermits()!=0)
			try {
				sema.acquire();
				System.out.println("sema획득");
				this.dx = dx;
				Thread.sleep(15);
				sema.release();
				System.out.println("sema드롭");
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	public double getDy() {
		return dy;
	}

	public void setDy(double dy) {

		if(sema.availablePermits()!=0)
		try {
			sema.acquire();
			System.out.println("sema획득");
			this.dy = dy;
			Thread.sleep(15);
			sema.release();
			System.out.println("sema드롭");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void setSpeed(double speed) {
		this.speed = speed;
	}

	public double getPre_x() {
		return pre_x;
	}

	public void setPre_x(double pre_x) {
		this.pre_x = pre_x;
	}

	public double getPre_y() {
		return pre_y;
	}

	public void setPre_y(double pre_y) {
		this.pre_y = pre_y;
	}

	public double getx() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double gety() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

	public boolean isBallclear() {
		return ballclear;
	}

	public void setBallclear(boolean ballclear) {
		this.ballclear = ballclear;
	}

	public int getR() {
		return r;
	}

	public void setR(int r) {
		this.r = r;
	}
	
	public Semaphore getSema() {
		return sema;
	}

	public void setSema(Semaphore sema) {
		this.sema = sema;
	}

}
