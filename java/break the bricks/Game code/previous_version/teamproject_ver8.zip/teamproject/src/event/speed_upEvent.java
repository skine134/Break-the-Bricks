package event;

import java.io.IOException;

import org.omg.CORBA.PUBLIC_MEMBER;

import arkanoid_object.ball;
import arkanoid_object.brick;
import arkanoid_object.character;

public class speed_upEvent extends Item {
	
	public speed_upEvent(character ch, brick br, ball b) throws IOException {
		setPan(new ItemImagePanel());
		setCh(ch);
		setBr(br);
		setB(b);
		setSize_x(40);
		setSize_y(20);
		setItem_image("images\\Block\\Block_red.png");
		setDrop_th(new Thread(drop_event()));
	}
	
	@Override
	public void play_event() {
		if (getB().getSpeed() < ball.max_speed)
			getB().setSpeed(getB().getSpeed() * 1.1);
		else
			getB().setSpeed(ball.max_speed);
	}

}
