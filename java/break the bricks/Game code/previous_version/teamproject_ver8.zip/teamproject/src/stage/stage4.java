package stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import arkanoid_object.ball;
import arkanoid_object.brick;
import arkanoid_object.character;
import teamproject_Game.Music;

public class stage4 extends Stage{

	public stage4(character ch, ball b) throws IOException {
		stage_num = 4;
		bricks = new ArrayList<brick>();
		bricks_th = new ArrayList<Thread>();
		Unbreak_bricks=new ArrayList<brick>();
		for (int i = 0; i < 12; i++) {
			for (int j = 0; j < 3; j++) {
				bricks.add(3*i+j, new brick());
				bricks.get(3*i+j).setX(60 +50 * j);
				bricks.get(3*i+j).setY(180+20*i);
				bricks.get(3*i+j).setCollision(b);
				bricks_th.add(3*i+j, new Thread(bricks.get(3*i+j).th));
				bricks.get(3*i+j).getPan().setSize(bricks.get(3*i+j).getSize_x(), bricks.get(3*i+j).getSize_y());
				bricks.get(3*i+j).getPan().setLocation(bricks.get(3*i+j).getX(), bricks.get(3*i+j).getY());
				bricks.get(3 * i + j).setBrick_image("images\\Block\\Block_red.png");
			}
			}
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 3; j++) {
				bricks.add(3*i+j+36, new brick());
				bricks.get(3*i+j+36).setX(210 +50 * j);
				bricks.get(3*i+j+36).setY(100+20*i);
				bricks.get(3*i+j+36).setCollision(b);
				bricks_th.add(3*i+j+36, new Thread(bricks.get(3*i+j+36).th));
				bricks.get(3*i+j+36).getPan().setSize(bricks.get(3*i+j+36).getSize_x(), bricks.get(3*i+j+36).getSize_y());
				bricks.get(3*i+j+36).getPan().setLocation(bricks.get(3*i+j+36).getX(), bricks.get(3*i+j+36).getY());
				bricks.get(3 * i + j+36).setBrick_image("images\\Block\\Block_red.png");
			}
			}
		for (int i = 0; i < 12; i++) {
			for (int j = 0; j < 3; j++) {
				bricks.add(3*i+j+66, new brick());
				bricks.get(3*i+j+66).setX(360 +50 * j);
				bricks.get(3*i+j+66).setY(180+20*i);
				bricks.get(3*i+j+66).setCollision(b);
				bricks_th.add(3*i+j+66, new Thread(bricks.get(3*i+j+66).th));
				bricks.get(3*i+j+66).getPan().setSize(bricks.get(3*i+j+66).getSize_x(), bricks.get(3*i+j+66).getSize_y());
				bricks.get(3*i+j+66).getPan().setLocation(bricks.get(3*i+j+66).getX(), bricks.get(3*i+j+66).getY());
				bricks.get(3 * i + j+66).setBrick_image("images\\Block\\Block_red.png");
			}

			StageMusic=new Music("sounds\\background_music\\fire.mp3",true);
		}
	}
	@Override
	public String getH_wall() {
		return "images\\Fire\\fire_pillar_cols.png";
	}
	@Override
	public String getW_wall() {
		return "images\\Fire\\fire_pillar_rows.png";
	}
	@Override
	public String getball_image() {
		return "images\\Fire\\fire_ball.png";
	}
	@Override
	public String getBackground_image() {
		return "images\\Fire\\fire_back.png";
	}
}
