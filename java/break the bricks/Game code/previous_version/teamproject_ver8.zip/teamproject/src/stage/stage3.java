package stage;

import java.awt.Color;
import java.io.IOException;
import java.util.*;
import arkanoid_object.*;
import teamproject_Game.Music;

public class stage3 extends Stage {

	public stage3(character ch, ball b) throws IOException {
		stage_num = 3;
		bricks = new ArrayList<brick>();
		bricks_th = new ArrayList<Thread>();
		Unbreak_bricks = new ArrayList<brick>();

		// 5 15 25 마다 턴 전환
		// 11 왼쪽 끝 좌표 오른쪽 끝 좌표552 끝 좌표
		int turn = 1;
		int save1 = -23;
		int save2 = 573;
		for (int i = 0; i < 26; i++) {
			for (int j = 0; j < 2; j++) {
				bricks.add(2 * i + j, new brick());
				if ((i == 11 || i == 21) && j == 0) {
					turn *= -1;
				}
				if (j % 2 == 0) {
					save1 += 50 * turn;
					bricks.get(2 * i + j).setX(save1);
				} else {
					save2 -= 50 * turn;
					bricks.get(2 * i + j).setX(save2);
				}
				bricks.get(2 * i + j).setY(11 + 20 * i);
				bricks.get(2 * i + j).setCollision(b);
				bricks_th.add(2 * i + j, new Thread(bricks.get(2 * i + j).th));
				bricks.get(2 * i + j).getPan().setSize(bricks.get(2 * i + j).getSize_x(), bricks.get(2 * i + j).getSize_y());
				bricks.get(2 * i + j).getPan().setLocation(bricks.get(2 * i + j).getX(), bricks.get(2 * i + j).getY());
				if ((2 * i + j )% 4 == 0)
					bricks.get(2 * i + j).setBrick_image("images\\Block\\Block_sky.png");
				else if ((2 * i + j )% 4 == 1)
					bricks.get(2 * i + j).setBrick_image("images\\Block\\Block_white.png");
				else if ((2 * i + j )% 4 == 2)
					bricks.get(2 * i + j).setBrick_image("images\\Block\\Block_navy.png");
				else
					bricks.get(2 * i + j).setBrick_image("images\\Block\\Block_blue.png");
			}
		}

		StageMusic=new Music("sounds\\background_music\\ice.mp3",true);
	}

	@Override
	public String getH_wall() {
		return "images\\ice\\ice_pillar_cols.png";
	}

	@Override
	public String getW_wall() {
		return "images\\ice\\ice_pillar_rows.png";
	}

	@Override
	public String getball_image() {
		return "images\\ice\\ice_ball.png";
	}

	@Override
	public String getBackground_image() {
		return "images\\ice\\ice_back.png";
	}
}
