package teamproject_Game;

import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.concurrent.Semaphore;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

public class main_menu extends Thread {

	ImagePanel start_title;
	ImageIcon startButtonEnterImage;
	ImageIcon startButtonBasicImage;
	JButton start;
	boolean flag;

//************************************메인화면
	main_menu() {
		start_title = new ImagePanel("images//startTitle.png");
		start_title.setSize(600, 1000);
		startButtonEnterImage = new ImageIcon("images//startButton//startbuttonExited.png");
		startButtonBasicImage = new ImageIcon("images//startButton//startbutton.png");
		start = new JButton(startButtonBasicImage);
		start.setLocation(100, 300);
		start.setSize(400, 200);
		start.setBorderPainted(false);
		start.setContentAreaFilled(false);
		start.setFocusPainted(false);
		flag = false;
	}

	public void run() {
		Game.getmove_th().suspend();
		Game.getCon().add(start_title);
		Music introMusic = new Music("sounds\\background_music\\title.mp3", true);
		Game.getCon().setComponentZOrder(start_title, 0);
		Game.getCon().repaint();
		new Thread(introMusic.th).start();
		start.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseEntered(MouseEvent e) {
				start.setIcon(startButtonEnterImage);
				start.setCursor(new Cursor(Cursor.HAND_CURSOR));
			}

			@Override
			public void mouseExited(MouseEvent e) {
				start.setIcon(startButtonBasicImage);
				start.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}

			@Override
			public void mousePressed(MouseEvent e) {
				Game.getCon().remove(start_title);
				Game.getCon().remove(start);
				flag = true;
				Game.getmove_th().resume();
				Game.getCon().repaint();
				introMusic.close();
			}
		});
		start_title.add(start);
		while (true) {
			if (flag == true)
				break;
			try {
				Thread.sleep(1000 / 60);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		}
	}

	class ImagePanel extends JPanel {
		Image image;

		public ImagePanel(String filename) {
			image = new ImageIcon(filename).getImage();
		}

		@Override
		public void paint(Graphics g) {
			g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
			setOpaque(false);
			super.paint(g);
		}

	}
}
