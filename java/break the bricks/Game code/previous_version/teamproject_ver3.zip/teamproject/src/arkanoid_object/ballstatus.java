package arkanoid_object;

import java.util.concurrent.Semaphore;

import javax.swing.ImageIcon;
import javax.swing.JComponent;

public class ballstatus extends JComponent {

	// 배속
	private double speed;

	// 이전 x,y값
	private int pre_x;
	private int pre_y;

	// 현제 x,y값
	private int x;
	private int y;

	// 공의 투명성 여부
	private boolean ballclear;

	// 공의 지름
	private int r;

	// 각 축에대한 공의 변화량
	private int dx;
	private int dy;

	// 충돌이 여러블록에서 한번에 일어 났을 경우 방향 전환이 한번만 되게 하기 외한 Semaphore
	private Semaphore Xsema;
	private Semaphore Ysema;

	public double getSpeed() {
		return speed;
	}

	public int getDx() {
		return dx;
	}

	public void setDx(int dx) {
		if(Xsema.availablePermits()>0)
			try {
				Xsema.acquire();
				this.dx = dx;
				Thread.sleep(10);
				Xsema.release();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	public int getDy() {
		return dy;
	}

	public void setDy(int dy) {

		if(Ysema.availablePermits()>0)
		try {
			Ysema.acquire();
			this.dy = dy;
			Thread.sleep(10);
			Ysema.release();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void setSpeed(double speed) {
		this.speed = speed;
	}

	public int getPre_x() {
		return pre_x;
	}

	public void setPre_x(int pre_x) {
		this.pre_x = pre_x;
	}

	public int getPre_y() {
		return pre_y;
	}

	public void setPre_y(int pre_y) {
		this.pre_y = pre_y;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public boolean isBallclear() {
		return ballclear;
	}

	public void setBallclear(boolean ballclear) {
		this.ballclear = ballclear;
	}

	public int getR() {
		return r;
	}

	public void setR(int r) {
		this.r = r;
	}

	public Semaphore getXSema() {
		return Xsema;
	}

	public void setXSema(Semaphore Xsema) {
		this.Xsema = Xsema;
	}
	
	public Semaphore getYSema() {
		return Ysema;
	}

	public void setYSema(Semaphore Ysema) {
		this.Ysema = Ysema;
	}

}
