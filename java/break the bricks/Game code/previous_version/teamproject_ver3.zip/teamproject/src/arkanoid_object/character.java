package arkanoid_object;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;

import event.Item;
import teamproject_Game.Game;

public class character extends character_status {

	// 충돌 처리를 위한 함수 람다식으로 구현
	private Collision ball_col = (JComponent e) -> {
		
		ball b=(ball)e;
		// 만약 캐릭터와 충돌 했을때 true 반환 충돌하지 않았다면 false 반환
		if ((b.getX() + b.getR()) >= this.getX() && 
			(b.getY() + b.getR()) >= this.getY()&& 
			(b.getX()) <= (this.getX() + this.getSize_x()) &&
			(b.getY()) <= (this.getY() + this.getSize_y())) {
			return true;
		} else
			return false;
	};
	
	// 아이템 충돌 처리를 위한 함수 람다식으로 구현
	private Collision items_col=(JComponent e) -> {
		
		Item i=(Item)e;
		// 만약 캐릭터와 충돌 했을때 true 반환 충돌하지 않았다면 false 반환
		if ((i.getX()+i.getSize_x()) >= this.getX() && 
			(i.getY()+i.getSize_y()) >= this.getY()&& 
			(i.getX()) <= (this.getX() + this.getSize_x()) &&
			(i.getY()) <= (this.getY() + this.getSize_y())) {
			return true;
		} else
			return false;
	};
	// character에대한 스레드 선언
	public Runnable ball_th;
	public Runnable items_th;
	// character을 담아낼 pan 선언
	private JPanel pan;
	
	private BufferedImage image;
	

	private ArrayList<JLabel> hp_pans;
	public character() throws IOException {

		// character의 x사이즈 설정(※y사이즈는 변동될 일이 없으므로 선언 전에 설정 됌)
		setSize_x(100);

		// character의 x좌표 선언(※y좌표는 변동될 일이 없으므로 선언 전에 설정 됌)
		setX(246);

		// character의 hp 구현(3칸)
		setHp(3);

		// character의 초기 x벡터선언(※y벡터는 변동될 일이 없으므로 구현되지 않음)
		setDx(0);

		// character을 담아낼 pan 객체 선언 및 이미지 지정
		pan = new CharacterImagePanel();

		// character을 담아낼 pan의 사이즈 지정
		pan.setSize(getSize_x(), getSize_y());
		setCharacter_image("images\\character.png");
		
		hp_pans = new ArrayList<JLabel>(3);
		// hp의 이미지 추가
		for (int i = 0; i < 3; i++)
			hp_pans.add(i, new JLabel(new ImageIcon("images\\heart.png")));
	}

	class CharacterImagePanel extends JPanel{
		 @Override
	        public void paint(Graphics g) {
	            g.drawImage(image, 0, 0,getWidth(),getHeight(), null);
	        }
	       
	        @Override
	        public Dimension getPreferredSize() {
	            if (image == null) {
	                return new Dimension(600, 1000);
	            } else {
	                return new Dimension(image.getWidth(), image.getHeight());
	            }
	        }
	}
	
	public void setCharacter_image(String str) throws IOException {
		image=ImageIO.read(new File(str));
	}
	
	public ArrayList<JLabel> getHp_pans() {
		return hp_pans;
	}



	public void setHp_pan(ArrayList<JLabel> hp_pans) {
		this.hp_pans = hp_pans;
	}

//hp를 증가시킴
	public void Hpadd() {
		this.setHp(this.getHp()+1);
//		// 게임의 테스트를위해 주석처리(필요에 따라 주석처리를 없애도 됌)
//		this.getHp_pans().add(this.getHp_pans().size()-1, new JLabel(new ImageIcon("images\\heart.png")));
//		this.getHp_pans().get(this.getHp_pans().size()-1).setSize(50, 50);
//		this.getHp_pans().get(this.getHp_pans().size()-1).setLocation(500- (this.getHp_pans().size()-1)* 50, 15);
//		Game.getCon().add(this.getHp_pans().get(this.getHp_pans().size()-1));
	}
	

//hp를 감소시킴
	public void Hpremove() {
		this.setHp(this.getHp()-1);
//		// 게임의 테스트를위해 주석처리(필요에 따라 주석처리를 없애도 됌)
//		Game.getCon().remove(this.getHp_pans().get(this.getHp()));
//		this.getHp_pans().remove(this.getHp());
//		Game.getCon().repaint();
//		if(this.getHp()<=0)
//			System.exit(1);
	}

	// character를 담은pan 반환
	public JPanel getPan() {
		return pan;
	}

	// 충돌 시 일어나는 이벤트 스레드구현
	public void setCollision(ball b) {

		ball_th = () -> {
			while (true) {

				// 만약 충돌이 일어났다면
				if (ball_col.collision(b)) {

					// 공의 y벡터는 반전 (다시 올라가도록)하고 공의 x벡터는 캐릭터가 움직이던중 이라면 움직이는 방향으로 설정
					if(b.getY()!=0&&this.getDx()!=0)
						b.setDx(this.getDx());
					b.setDy(-b.getDy());
					try {
						// 스레드가 연속해서 일어나는오류를 방지하기위해 충돌 후 0.5초간 상기된 이벤트 정지
						Thread.sleep(500);
					} catch (InterruptedException e) {
						e.getMessage();
					}
				}
				try {

					// 충돌에 대한 감시를 1초당60번 수행
					Thread.sleep(1000 / 60);
				} catch (InterruptedException e) {
					e.getMessage();
				}
			}
		};

	}

	//아이템 충돌 시 일어나는 이벤트 스레드구현
		public void setCollision(ArrayList<Item> items) {

			items_th = () -> {
				while (true) {
					//아이템을 갖고 있다면 하위의 명령어 실행
					if(items!=null)
					for(int i=0;i<items.size();i++) {
						
						//만약 충돌이 일어났다면
						if (items_col.collision(items.get(i))) {
							
							//아이템의 이벤트 실헹
							items.get(i).play_event(this);
							items.get(i).getPan().setVisible(false);
							items.remove(i);
							
						}
					}
					try {
						
						//충돌에 대한 감시를 1초당60번 수행
						Thread.sleep(1000 / 60);
					} catch (InterruptedException e) {
						e.getMessage();
					}
				}
			};

		}
}
