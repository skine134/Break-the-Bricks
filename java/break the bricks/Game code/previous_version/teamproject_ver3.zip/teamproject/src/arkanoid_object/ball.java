package arkanoid_object;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.Semaphore;

import javax.imageio.ImageIO;
import javax.swing.*;

public class ball extends ballstatus {
	public Runnable th;
	
	private BufferedImage image;



	private JPanel pan = new ballImagePanel();
	public ball(character ch) {
		//공의 투명성 여부 설정
		setBallclear(false);
		
		//공의 지름크기 설정
		setR(20);
		//공의   초기 x값,y값 설정(캐릭터의 중앙 위에 위치하도록 설정)
		setX(ch.getX() + (int) (ch.getSize_x() / 2) - getR() / 2);
		setY(ch.getY() - getR());
		//공의 초기 스피드 설정
		setSpeed(Math.sqrt(9)/2);
		
		//공을 표시할 패널의 사이즈 설정
		pan.setSize(getR(), getR());
		
		//X,Y벡터에 대한 세마포어 설정(동시 접근방지)
		setXSema(new Semaphore(1));
		setYSema(new Semaphore(1));
		
		//공에 대한 스레드 람다식으로 설정
		th = () -> {
			while (true) {
				
				//만약 공이 움직이지 않았을 경우(게임 시작 전)
				if (this.getDy() == 0) {
					
					//이전 공의 x값에 현제 x,y값 지정
					this.setPre_x(this.getX());
					this.setPre_y(this.getY());
					//현제 x,y값 변경(캐릭터를 쫒아가도록)
					this.setX(ch.getX() + (int) (ch.getSize_x() / 2) - getR() / 2);
					this.setY(ch.getY() - getR());
					
					
				} 
				//만약 공이 움직이고 있었을 경우
				else {
					
					//공이 위아래 벽에 부딛혔을 경우 y벡터값 반전
					if (this.getY() < 11 /*|| this.getY() > 933*/)
						this.setDy(-this.getDy());
					
					if( this.getY() > 933) {
						this.reset(ch);
						ch.Hpremove();
					}
						
					//공이 좌우 벽에 부딛혔을 경우 x벡터값 반전
					if (this.getX() < 11 || this.getX() > 552)
						this.setDx(-this.getDx());
					
					//이전 x,y값을 현제 x,y값 으로 설정
					this.setPre_x(this.getX());
					this.setPre_y(this.getY());
					
					//현제 x,y값을 변경
					this.setX(this.getX() + this.getDx());
					this.setY(this.getY() + this.getDy());
					
				}
				//공을 표시하는 팬의 위치를 현제 x,y값에 맞춰 변경
				this.pan.setLocation(this.getX(), this.getY());
				try {
					
					//1초에 60번 스레드 동작
					Thread.sleep(1000 / 60);
				} catch (InterruptedException e) {
					e.getMessage();
				}
			}

		};
	}

	class ballImagePanel extends JPanel{
		 @Override
	        public void paint(Graphics g) {
	            g.drawImage(image, 0, 0, null);
	        }
	       
	        @Override
	        public Dimension getPreferredSize() {
	            if (image == null) {
	                return new Dimension(600, 1000);
	            } else {
	                return new Dimension(image.getWidth(), image.getHeight());
	            }
	        }
	}
	//공을 가지고 있는 패널을 반환해줌
	public JPanel getPan() {
		return pan;
	}
	public void reset(character ch) {
		setDy(0);
		setDx(0);
		setX(ch.getX() + (int) (ch.getSize_x() / 2) - getR() / 2);
		setY(ch.getY() - getR());
	}
	public void setball_image(String str) throws IOException {
		image=ImageIO.read(new File(str));
	}

}
