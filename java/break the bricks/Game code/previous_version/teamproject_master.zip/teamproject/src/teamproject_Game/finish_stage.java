package teamproject_Game;

import java.awt.Cursor;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import teamproject_Game.Game;
import arkanoid_object.*;

public class finish_stage extends Thread {

	ImagePanel clear_title;
	
	ImageIcon HomeEnter;
	ImageIcon HomeBasic;
	ImageIcon ExitEnter;
	ImageIcon ExitBasic;
	JButton Home;
	JButton Exit;
	boolean flag;

	main_menu title=new main_menu();
	public finish_stage() {
		clear_title = new ImagePanel("images//end.png");
		clear_title.setSize(600, 1000);
		HomeEnter = new ImageIcon("images//mainmenuButton//mainmenu_Enter.png");
		HomeBasic = new ImageIcon("images//mainmenuButton//mainmenu_Basic.png");
		ExitEnter = new ImageIcon("images//ExitButton//ExitButton_Enter.png");
		ExitBasic = new ImageIcon("images//ExitButton//ExitButton_Basic.png");
		Home = new JButton(HomeBasic);
		Home.setLocation(100, 300);
		Home.setSize(400, 200);
		Home.setBorderPainted(false);
		Home.setContentAreaFilled(false);
		Home.setFocusPainted(false);
		flag = false;
		Exit = new JButton(ExitBasic);
		Exit.setLocation(400, 300);
		Exit.setSize(400, 200);
		Exit.setBorderPainted(false);
		Exit.setContentAreaFilled(false);
		Exit.setFocusPainted(false);
		flag = false;
	}

	public void run() {
		//Game.getmove_th().suspend();
		Game.getCon().add(clear_title);
		Music clearMusic = new Music("sounds\\background_music\\title.mp3", true);
		Game.getCon().setComponentZOrder(clear_title, 0);
		Game.getCon().repaint();
		//new Thread(introMusic.th).start();
		Home.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseEntered(MouseEvent e) {
				Home.setIcon(HomeEnter);
				Home.setCursor(new Cursor(Cursor.HAND_CURSOR));
			}

			@Override
			public void mouseExited(MouseEvent e) {
				Home.setIcon(HomeBasic);
				Home.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}

			@Override
			public void mousePressed(MouseEvent e) {

				flag = true;
				Game.getCon().removeAll();
				Game.getCon().repaint();
				character.flag=true;
				Application.mainmenuThreadreset();
				Application.GameThreadreset();
				clearMusic.close();
				Application.mainmenuThread().start();
				
			}
		});
		
		Exit.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseEntered(MouseEvent e) {
				Exit.setIcon(ExitEnter);
				Exit.setCursor(new Cursor(Cursor.HAND_CURSOR));
			}

			@Override
			public void mouseExited(MouseEvent e) {
				Exit.setIcon(ExitBasic);
				Exit.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}

			@Override
			public void mousePressed(MouseEvent e) {
				System.exit(1);
			}
		});
		
		clear_title.add(Home);
		clear_title.add(Exit);
		while (true) {
			if (flag)
				break;
			try {
				Thread.sleep(1000 / 60);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		}
	}

	class ImagePanel extends JPanel {
		Image image;

		public ImagePanel(String filename) {
			image = new ImageIcon(filename).getImage();
		}

		@Override
		public void paint(Graphics g) {
			g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
			setOpaque(false);
			super.paint(g);
		}

	}
}