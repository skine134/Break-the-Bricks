package teamproject_Game;

import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

public class Game_Clear extends Thread{
	Game_Clear(){
		
	}
	
	
}
