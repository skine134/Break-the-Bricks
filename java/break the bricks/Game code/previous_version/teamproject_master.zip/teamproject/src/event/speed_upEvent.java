package event;

import java.io.IOException;

import org.omg.CORBA.PUBLIC_MEMBER;

import arkanoid_object.Item;
import arkanoid_object.ball;
import arkanoid_object.brick;
import arkanoid_object.character;

public class speed_upEvent extends Item {
	
	public speed_upEvent(character ch, brick br, ball b) throws IOException {
		super(ch,br,b);
	}
	
	@Override
	public void play_event() {
		double check_max=getB().getSpeed() * 1.1;
		if (check_max < ball.max_speed)
			getB().setSpeed(getB().getSpeed() * 1.1);
		else
			getB().setSpeed(ball.max_speed);

		getB().setDx(getB().getDx()*Math.sqrt(getB().getSpeed()));
		getB().setDy(getB().getDy()*Math.sqrt(getB().getSpeed()));
	}

}
