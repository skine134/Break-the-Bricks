package stage;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.io.IOException;
import java.util.*;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

import arkanoid_object.*;
import event.*;
public class stage1 {
	private ArrayList<brick> bricks;
	private ArrayList<Thread> bricks_th;
	private int stage_num;
	public stage1(character ch,ball b) throws IOException {
		stage_num = 1;
		bricks = new ArrayList<brick>();
		bricks_th = new ArrayList<Thread>();
		for (int i = 0; i < 7; i++) {
			bricks.add(i, new brick());
			bricks.get(i).setX(150 + 50 * i);
			bricks.get(i).setY(400);
			bricks.get(i).setCollision(b);
			bricks_th.add(i, new Thread(bricks.get(i).th));
			bricks.get(i).getPan().setSize(bricks.get(i).getSize_x(), bricks.get(i).getSize_y());
			bricks.get(i).getPan().setLocation(bricks.get(i).getX(), bricks.get(i).getY());
			bricks.get(i).setBrick_image("images\\Block\\Block_green.png");
			if(i%2==0)
			bricks.get(i).setItem(new long_barEvent(ch,bricks.get(i),b));
			else
				bricks.get(i).setItem(new big_ballEvent(ch,bricks.get(i),b));
		};
	}

	public HashMap<Integer, ArrayList<Thread>> returnbricks() {
		HashMap<Integer, ArrayList<Thread>> map = new HashMap<Integer, ArrayList<Thread>>();
		map.put(stage_num, bricks_th);
		return map;
	}

	public ArrayList<brick> getBricks() {
		return bricks;
	}

	public ArrayList<Thread> getBricks_th() {
		return bricks_th;
	}

	public int getStage_num() {
		return stage_num;
	}
	public String getH_wall(){
		return "images\\forest\\forest_pillar_cols.png";
	}
	public String getW_wall(){
		return "images\\forest\\forest_pillar_rows.png";
	}
	public String getball_image() {
		return "images\\forest\\forest_ball.png";
	}
	public String getBackground_image() {
		return "images\\forest\\forest_back.png";
	}
}