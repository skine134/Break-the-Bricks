package event;

import java.io.IOException;

import arkanoid_object.ball;
import arkanoid_object.brick;
import arkanoid_object.character;
import event.Item.ItemImagePanel;

public class big_ballEvent extends Item{
	//아래 생성자의 양식은 어떤 이벤트든 동일 해야함 (이벤트에 상호작용 하는 오브젝트는 벽돌,캐릭터,공 이기 때문)
		public big_ballEvent(character ch,brick br,ball b) throws IOException{
			setPan(new ItemImagePanel());
			setCh(ch);
			setBr(br);
			setB(b);
			setSize_x(40);
			setSize_y(20);
			setItem_image("images\\Block\\Block_red.png");
			setDrop_th(new Thread(drop_event()));
		}
		
		
		//아래 함수에서 일어나야할 이벤트 정의
		@Override
		public void play_event() {
			getB().setR(getB().getR()+10);
			getB().getPan().setSize(getB().getR(),getB().getR()); 
		}
}
