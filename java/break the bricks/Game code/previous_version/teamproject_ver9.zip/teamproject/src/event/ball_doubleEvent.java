package event;

import java.awt.Color;


import java.io.IOException;

import javax.swing.JPanel;
import arkanoid_object.*;
import teamproject_Game.Game;

public class ball_doubleEvent extends Item {

	public ball_doubleEvent(character ch, brick br, ball b) throws IOException {
		super(ch, br, b);
	}

	@Override
	public void play_event() {
		ball b2 = new ball(getCh());
		try {
			b2.setball_image(Game.getStages().get(Game.getstageNum()).getball_image());
		} catch (IOException e) {
			e.printStackTrace();
		}
		b2.setSize(50,50);
		b2.getPan().setLocation((int)getB().getx(),(int)getB().gety());
		double immediatly=Math.pow(getB().getDx(),2)+Math.pow(getB().getDy(), 2);
		if(getB().getDx()==0) {
			if(getB().getDy()<0) {
				getB().setDy(getB().getDy()*4/5);
				getB().setDx(Math.sqrt(immediatly-getB().getDy()));
			}
			else {
				getB().setDy(getB().getDy()*4/5);
				getB().setDx(-Math.sqrt(immediatly-getB().getDy()));
			}
			b2.setDy(getB().getDy());
			b2.setDx(-getB().getDx());
		}
		else {
			getB().setDx(getB().getDy()*6/5);
			if(getB().getDy()<0)
			getB().setDy(-Math.sqrt(immediatly-Math.pow(getB().getDx(), 2)));
			else
				getB().setDy(Math.sqrt(immediatly-Math.pow(getB().getDx(), 2)));
			b2.setDy(getB().getDx());
			b2.setDx(getB().getDy());
		}
		Game.getCon().add(b2.getPan());
		getCh().setCollision(b2);
		Game.getCon().repaint();
		Game.getCon().setComponentZOrder(b2.getPan(), 0);
		new Thread(getCh().balls_th.get(b2.getball_num()-1)).start();
		new Thread(b2.th).start();
	}

}