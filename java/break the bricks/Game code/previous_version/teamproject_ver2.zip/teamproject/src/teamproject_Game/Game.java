package teamproject_Game;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.*;
import javax.swing.*;
import arkanoid_object.*;
import event.Item;
import stage.*;

public class Game extends JFrame {

	// 배경화면
	BackgroundImage background;

	// 벽
	Wall[] wall;

	// 컨테이너
	private static Container con;

	// 공
	ball b;

	// 캐릭터(유저)
	character ch;

	// 이동을 위한 논리식
	boolean left;
	boolean right;

	// 각 스테이지 벽돌의 스레드 모음집
	HashMap<Integer, ArrayList<Thread>> bricks_th;

	// 아이템 관리 모음집
	public static ArrayList<Item> items = new ArrayList<Item>();;

	// 각 객채에 대한 스레드
	Thread ball_th;
	Thread ch_ball_th;
	Thread move_th;
	Thread ch_items_th;
	Runnable move;
	stage1 st1;
	stage2 st2;
	stage3 st3;
	stage4 st4;
	stage5 st5;
	ArrayList<JLabel> hp;

	Game() throws IOException {
//*************************************기본 셋팅
		// 이름 지정
		setTitle("벽돌 깨기");

		// 게임 종료시 콘솔도 종료
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		// 메인 창 활성화
		setVisible(true);

		// 어플 크기 지정
		setSize(600, 1000);
		// 컨테이너에 컨텐츠팬 삽입
		con = getContentPane();
//*************************************각 객체의 선언
		ch = new character();
		wall = new Wall[4];
		b = new ball(ch);
		background = new BackgroundImage();
		ch.setCollision(b);
		ch_ball_th = new Thread(ch.ball_th);
		ch.setCollision(items);
		ch_items_th = new Thread(ch.items_th);
		ball_th = new Thread(b.th);
		hp = new ArrayList<JLabel>(3);

		// 움직임 제어를 위한 로직
		left = false;
		right = false;

		// hp의 이미지 추가
		for (int i = 0; i < 3; i++)
			hp.add(i, new JLabel(new ImageIcon("images\\heart.png")));

		// 각 스테이지의 벽돌들에 대한 객체 선언
		bricks_th = new HashMap<Integer, ArrayList<Thread>>();

		// 각 스테이지에 대한 객체 선언
		st1 = new stage1(ch, b);
		st2 = new stage2(ch, b);
		st3 = new stage3(ch, b);
		st4 = new stage4(ch, b);

		// 각 스테이지의 블록에 관한 스레드를 관리하는 컬랙션에 1스테이지의 블록들에 관한 스레드를 삽입
		bricks_th.putAll(st1.returnbricks());
		bricks_th.putAll(st2.returnbricks());
		bricks_th.putAll(st3.returnbricks());
		bricks_th.putAll(st4.returnbricks());

		// 움직임에 대한 스레드 람다식으로 지정
		move = () -> {
			while (true) {

				// 만약 right==true이면 아래의 명령어 수행
				if (right) {

					// 만약 캐릭터가 화면의 오른쪽 끝에 닿지 않았다면 현제 캐릭터의 속도만큼 캐릭터를 오른쪽으로 이동
					if (ch.getX() <= 572 - ch.getSize_x()) {
						ch.setX(ch.getX() + ch.getDx());
						ch.getPan().setLocation(ch.getX(), ch.getY());
					}

					// 만약 right==true이면 아래의 명령어 수행
				} else if (left) {

					// 만약 캐릭터가 화면의 왼쪽 끝에 닿지 않았다면 현제 캐릭터의 속도만큼 캐릭터를 왼쪽으로 이동
					if (ch.getX() >= 10) {
						ch.setX(ch.getX() + ch.getDx());
						ch.getPan().setLocation(ch.getX(), ch.getY());
					}
				}
				try {
					// 위의 검사를 1초에 60번 수행(＊부러운 움직임을 위함)
					Thread.sleep(1000 / 60);
				} catch (InterruptedException e) {
					e.getMessage();
				}
			}
		};
		// move_th의 선언(move는 Runable 클래스로 선언 되었으므로 Thread에 포함 시켜주어야함).
		move_th = new Thread(move);

//*************************************배치 및 이벤트 설정

		// 컨테이너의 배치타입(Layout)을 null로 지정(크기와 좌표로 각 객체를 배치함)
		con.setLayout(null);

		// 벽에 대한 배치
		for (int i = 0; i < 4; i++) {

			// 각 벽에대한 객체 선언
			wall[i] = new Wall();

			// 만약 i가 0,1이면 10,953 로 막대 크기를 지정(세로 막대)
			if (i < 2)
				wall[i].getPan().setSize(10, 953);

			// 만약 i가 2,3이면 582,10 로 막대 크기를 지정(가로 막대)
			else
				wall[i].getPan().setSize(582, 10);
		}

		// 각 벽의 컨테이너에 배치 및 위치 지정
		con.add(wall[0].getPan());
		wall[0].getPan().setLocation(0, 10);
		con.add(wall[1].getPan());
		wall[1].getPan().setLocation(572, 10);
		con.add(wall[2].getPan());
		wall[2].getPan().setLocation(0, 0);
		con.add(wall[3].getPan());
		wall[3].getPan().setLocation(0, 943);

		// 현제 hp를 보여주는 이미지를 오른쪽 상단에 표시
		for (int i = 0; i < hp.size(); i++) {
			con.add(hp.get(i));
			hp.get(i).setSize(50, 50);
			hp.get(i).setLocation(400 + i * 50, 15);
		}

		// 캐릭터의 컨테이너에 배치 및 위치 지정
		con.add(ch.getPan());
		ch.getPan().setLocation(ch.getX(), ch.getY());

		// 공의 컨테이너에 배치 및 위치 지정
		con.add(b.getPan());
		b.getPan().setLocation(b.getX(), b.getY());

		con.add(background.getPan());
		// 컨테이너에 키보드 리스너 이벤트를 부여함
		con.addKeyListener(new KeyListener() {

			@Override // 키가 눌렸을때 이벤트(※설정안함)
			public void keyTyped(KeyEvent e) {
			}

			@Override // 키를 누르고 있을때 이벤트
			public void keyPressed(KeyEvent e) {

				// 만약에 키가 눌려있는데 그 키가 왼쪽 방향키라면 아래 명령어 수행
				if (e.getKeyCode() == KeyEvent.VK_LEFT) {

					// 만약 캐릭터의 움직이지 않고 정지 상태라면(초기 상태에서 움직이지 않음) x축 벡터를 -5로 설정
					if (ch.getDx() == 0)
						ch.setDx(-5);
					else if (ch.getDx() > 0)

						// 만약 캐릭터가 이전에 오른쪽으로 움직이고 있었다면 x축 벡터방향을 반대로 변경
						ch.setDx(-ch.getDx());
					left = true;

					// 만약에 키가 눌려있는데 그 키가 오른 방향키라면 아래 명령어 수행
				} else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {

					// 만약 캐릭터의 움직이지 않고 정지 상태라면(초기 상태에서 움직이지 않음) x축 벡터를 +5로 설정
					if (ch.getDx() == 0)
						ch.setDx(5);

					// 만약 캐릭터가 이전에 왼쪽으로 움직이고 있었다면 x축 벡터방향을 반대로 변경
					else if (ch.getDx() < 0)
						ch.setDx(-ch.getDx());
					right = true;

				}

				// 만약에 키가 눌려있는데 그 키가 스페이스 방향키이고 공의 y축 백터가 0이라면(정지상태라면) 아래 명령어 수행
				if (e.getKeyCode() == KeyEvent.VK_SPACE && b.getDy() == 0) {

					// 캐릭터가 움직인 방향으로 공을 발사(정지해 있다면 수직으로 발사)
					if (ch.getDx() != 0)
						b.setDx((int) (b.getSpeed() * ch.getDx()));
					b.setDy((int) (-5 * b.getSpeed()));
				}

				// esc 버튼 클릭시 게임 종료
				if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
					System.exit(1);
				}
			}

			@Override // 누른 키가 떨어졌을때 이벤트
			public void keyReleased(KeyEvent e) {
				left = false;
				right = false;
				ch.setDx(0);
			}

		});

		// 각 스레드 동작
		ball_th.start();
		ch_ball_th.start();
		ch_items_th.start();
		move_th.start();

		// 키이벤트를 받을 수 있도록 컨테이너 설정
		con.setFocusable(true);
		con.requestFocus();

		// 스테이지별 게임 작동
		for (int i = 4; i <= bricks_th.size(); i++) {

			// 컨테이너에 n스테이지에 포함된 벽돌을 추가 및 배치
			if (i == 1) {
				for (int j = 0; j < st1.getBricks().size(); j++) {
					con.add(st1.getBricks().get(j).getPan());
				}
				for (int j = 0; j < wall.length; j++) {
					// 각 벽에 대한 이미지 지정
					if (j < 2)
						wall[j].setWall_image(st1.getH_wall());
					else
						wall[j].setWall_image(st1.getW_wall());

				}
				b.setball_image(st1.getball_image());
				background.setBackGround_image(st1.getBackground_image());
			} else if (i == 2) {
				for (int j = 0; j < st2.getBricks().size(); j++) {
					con.add(st2.getBricks().get(j).getPan());
				}
				for (int j = 0; j < wall.length; j++) {
					// 각 벽에 대한 이미지 지정
					if (j < 2)
						wall[j].setWall_image(st2.getH_wall());

					else
						wall[j].setWall_image(st2.getW_wall());
				}
				b.setball_image(st2.getball_image());
				background.setBackGround_image(st2.getBackground_image());
			} else if (i == 3) {
				for (int j = 0; j < st3.getBricks().size(); j++) {
					con.add(st3.getBricks().get(j).getPan());
				}
				for (int j = 0; j < wall.length; j++) {
					// 각 벽에 대한 이미지 지정
					if (j < 2)
						wall[j].setWall_image(st3.getH_wall());
					else
						wall[j].setWall_image(st3.getW_wall());
				}
				b.setball_image(st3.getball_image());
				background.setBackGround_image(st3.getBackground_image());
			} else if (i == 4) {
				for (int j = 0; j < st4.getBricks().size(); j++) {
					con.add(st4.getBricks().get(j).getPan());
				}
				for (int j = 0; j < wall.length; j++) {
					// 각 벽에 대한 이미지 지정
					if (j < 2)
						wall[j].setWall_image(st4.getH_wall());
					else
						wall[j].setWall_image(st4.getW_wall());
				}
				b.setball_image(st4.getball_image());
				background.setBackGround_image(st4.getBackground_image());
			}
			con.setComponentZOrder(background.getPan(), con.getComponentCount() - 1);
			con.repaint();
			// 스테이지별 벽돌들의 스레드 작동
			for (int j = 0; j < bricks_th.get(i).size(); j++) {
				(bricks_th.get(i)).get(j).start();
			}

			// 스레드가 모두 종료 될때 까지 무한 반복(한 스테이지에 머무르게 하기 위함)
			while (!(bricks_th.get(i)).isEmpty()) {
				for (int j = 0; j < bricks_th.get(i).size(); j++) {
					if (!(bricks_th.get(i)).get(j).isAlive())
						bricks_th.get(i).remove(j);
				}
			}
			b.reset(ch);
		}
	}

	public static void main(String args[]) throws IOException {
		new Game();

	}

	public static Container getCon() {
		return con;
	}
}
