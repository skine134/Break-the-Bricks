package event;

import java.io.IOException;

import arkanoid_object.ball;
import arkanoid_object.brick;
import arkanoid_object.character;
import event.Item.ItemImagePanel;

public class ball_smallEvent extends Item {
	
		public ball_smallEvent(character ch,brick br,ball b) throws IOException {
			setPan(new ItemImagePanel());
			setCh(ch);
			setBr(br);
			setB(b);
			setSize_x(40);
			setSize_y(20);
			setItem_image("images\\Block\\Block_red.png");
			setDrop_th(new Thread(drop_event()));
		
		}
		@Override
		public void play_event() {
			if(getB().getR() > ball.min_R) {
				getB().setR((int)(0.9*getB().getR()));
				getB().getPan().setSize(getB().getR(),getB().getR()); 
			}
			else {
				getB().setR(ball.min_R);
				getB().getPan().setSize(getB().getR(),getB().getR()); 
			}
		}

}
