package event;

import java.io.IOException;

import arkanoid_object.ball;
import arkanoid_object.brick;
import arkanoid_object.character;

public class speed_downEvent extends Item {

	public speed_downEvent(character ch, brick br, ball b) throws IOException {
		setCh(ch);
		setBr(br);
		setB(b);
		setSize_x(40);
		setSize_y(20);
		setItem_image("images\\Block\\Block_red.png");
		setDrop_th(new Thread(drop_event()));
	}
	
	@Override
	public void play_event() {
		if(ball.min_speed<getB().getSpeed())
		getB().setSpeed(getB().getSpeed()*0.3);
		else
			getB().setSpeed(ball.min_speed);
	}
	
}
